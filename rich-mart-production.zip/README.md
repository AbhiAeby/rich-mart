# 🛍️ Rich Mart - Full-Stack E-Commerce with WhatsApp Order Confirmation

A modern, high-converting full-stack online shopping website for **Rich Mart** (Online Sell BD). Built with Node.js, Express, Tailwind CSS, and instant WhatsApp order confirmation.

---

## 🚀 Features

- **Direct WhatsApp Order Confirmation**:
  - Automatically generates an organized, formatted WhatsApp message receipt with Order ID, customer name, contact phone, delivery address, ordered items with variants, and total price breakdown in BDT (৳).
  - Automatically opens WhatsApp directly with **Rich Mart's business number (`+880 1606-609110`)**.
  - Provides a one-click **"Copy Message Text"** button if WhatsApp web doesn't open automatically.
- **Bangladeshi E-commerce Tailored**:
  - Currency: BDT (`৳`)
  - Delivery rates: Inside Dhaka (`৳70`) & Outside Dhaka (`৳130`)
  - Automated **Free Delivery** calculation on orders above ৳2,000 with interactive progress bar.
  - Payment method: Cash on Delivery (COD - ক্যাশ অন ডেলিভারি).
- **Product Catalog & Cart**:
  - Live search with instant debouncing
  - Category filter tabs (Smart Gadgets, Audio, Fashion & Bags, Footwear, Accessories)
  - Sorting (Price Low-to-High, High-to-Low, Top Rated)
  - Product Quick View modal with color and size selectors
  - Slide-over Shopping Cart Drawer with quantity adjusters
  - One-Page quick checkout modal
- **Admin Control Panel (`/admin` or top navigation)**:
  - **Secure Access**: PIN protection (Default PIN: `1234`)
  - **Orders Management**: View customer name, phone, address, ordered items, and update order statuses (`Pending`, `Confirmed`, `Shipped`, `Delivered`, `Cancelled`).
  - **One-Click WhatsApp Chat with Customer**: Chat directly with customers from the admin panel.
  - **Product Management**: Add new products (with photos, categories, prices, badges, variants), edit existing ones, or delete items.
  - **Store Settings**: Change your WhatsApp number, phone number, delivery fees, and Facebook page link directly from the UI without touching code.

---

## 🛠️ How to Run

1. Open your terminal in `D:\Rich Mart`:
   ```bash
   npm start
   ```
2. Open your web browser:
   - **Storefront**: [http://localhost:3000](http://localhost:3000)
   - **Admin Panel**: Click **"Admin"** in the top navigation bar or enter PIN `1234`.

---

## 📱 WhatsApp Business Number & Facebook Info

- **Facebook Page**: [Rich Mart Facebook Page](https://www.facebook.com/people/Rich-Mart/61565633054658/)
- **WhatsApp & Helpline**: `01606609110` (International: `+8801606609110`)
- **Admin Default PIN**: `1234`

