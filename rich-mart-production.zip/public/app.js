// Rich Mart - Frontend Application (Clean, Bug-Free, Fully Responsive)

// =================== STATE ===================
const state = {
  products: [],
  categories: ['All'],
  selectedCategory: 'All',
  searchQuery: '',
  sortBy: 'featured',
  cart: [],
  settings: {
    storeName: 'Rich Mart',
    phone: '01606609110',
    whatsappNumber: '8801606609110',
    currency: '৳',
    deliveryInsideDhaka: 70,
    deliveryOutsideDhaka: 130,
    freeDeliveryThreshold: 2000
  },
  deliveryArea: 'inside_dhaka',
  activeModalProduct: null,
  modalSelectedColor: null,
  modalSelectedSize: null,
  modalQuantity: 1,
  adminPin: localStorage.getItem('rm_admin_pin') || '',
  adminOrders: []
};

// =================== INIT ===================
document.addEventListener('DOMContentLoaded', async () => {
  loadCartFromStorage();
  await fetchSettings();
  await fetchProducts();
  setupEventListeners();
  updateCartUI();
});

// =================== SETTINGS ===================
async function fetchSettings() {
  try {
    const res = await fetch('/api/settings');
    const data = await res.json();
    if (data.success && data.settings) {
      state.settings = { ...state.settings, ...data.settings };
      applySettingsToDOM();
    }
  } catch (err) {
    console.warn('Settings load failed:', err);
  }
}

function applySettingsToDOM() {
  const { storeName, phone, whatsappNumber, freeDeliveryThreshold, deliveryInsideDhaka, deliveryOutsideDhaka } = state.settings;
  const waUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent('Hello ' + storeName + ', I want to order!')}`;

  setInnerText('topPhoneDisplay', phone);
  setInnerText('topFreeDeliveryThreshold', freeDeliveryThreshold);
  setInnerText('footerPhone', phone);
  setInnerText('footerWa', phone + ' (WhatsApp)');
  setInnerText('labelInsideFee', deliveryInsideDhaka);
  setInnerText('labelOutsideFee', deliveryOutsideDhaka);
  setInnerText('chkInsideFee', deliveryInsideDhaka);
  setInnerText('chkOutsideFee', deliveryOutsideDhaka);

  setHref('floatingWaBtn', waUrl);
  setHref('footerWaIcon', waUrl);
}

function setInnerText(id, val) {
  const el = document.getElementById(id);
  if (el) el.innerText = val;
}

function setHref(id, href) {
  const el = document.getElementById(id);
  if (el) el.href = href;
}

// =================== PRODUCTS ===================
async function fetchProducts() {
  try {
    const url = new URL('/api/products', window.location.origin);
    if (state.selectedCategory && state.selectedCategory !== 'All') {
      url.searchParams.append('category', state.selectedCategory);
    }
    if (state.searchQuery) {
      url.searchParams.append('search', state.searchQuery);
    }

    const res = await fetch(url);
    const data = await res.json();
    if (data.success) {
      state.products = data.products;
      if (data.categories && data.categories.length > 1) {
        state.categories = data.categories;
        renderCategories();
      }
      renderProducts();
    }
  } catch (err) {
    console.error('Products fetch failed:', err);
    const grid = document.getElementById('productGrid');
    if (grid) grid.innerHTML = '<div class="col-span-full text-center text-sm text-red-500 py-10 font-bengali">পণ্য লোড করতে সমস্যা হয়েছে।</div>';
  }
}

function renderCategories() {
  const container = document.getElementById('categoryContainer');
  if (!container) return;

  container.innerHTML = state.categories.map(cat => {
    const isActive = state.selectedCategory === cat;
    const activeClass = isActive
      ? 'bg-slate-900 text-white shadow-sm'
      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200';
    const label = cat === 'All' ? 'সব পণ্য' : cat;
    return `<button onclick="selectCategory('${cat}')" class="px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition font-bengali ${activeClass}">${label}</button>`;
  }).join('');
}

function selectCategory(category) {
  state.selectedCategory = category;
  renderCategories();
  fetchProducts();
}

function renderProducts() {
  const grid = document.getElementById('productGrid');
  const empty = document.getElementById('emptyState');
  const countText = document.getElementById('productCountText');
  if (!grid) return;

  let list = [...state.products];

  if (state.sortBy === 'price-low') list.sort((a, b) => a.price - b.price);
  else if (state.sortBy === 'price-high') list.sort((a, b) => b.price - a.price);
  else if (state.sortBy === 'rating') list.sort((a, b) => b.rating - a.rating);

  if (countText) countText.innerText = `${list.length}টি পণ্য`;

  if (list.length === 0) {
    grid.innerHTML = '';
    if (empty) empty.classList.remove('hidden');
    return;
  }
  if (empty) empty.classList.add('hidden');

  grid.innerHTML = list.map(product => {
    const discount = product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 0;
    const cur = state.settings.currency;

    return `
      <div class="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden group">

        <div class="relative overflow-hidden aspect-square bg-slate-100 cursor-pointer" onclick="openProductModal('${product.id}')">
          <img src="${product.image}" alt="${escapeHtml(product.name)}" loading="lazy"
            class="w-full h-full object-cover group-hover:scale-105 transition duration-300">

          <div class="absolute top-2.5 left-2.5 flex flex-col gap-1">
            ${discount > 0 ? `<span class="bg-red-600 text-white font-black text-[10px] px-1.5 py-0.5 rounded shadow-sm">-${discount}%</span>` : ''}
            ${product.badge ? `<span class="bg-slate-900 text-white font-bold text-[9px] px-1.5 py-0.5 rounded uppercase tracking-wide shadow-sm">${product.badge}</span>` : ''}
          </div>

          <div class="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
            <span class="bg-white text-slate-900 text-[11px] font-bold px-3 py-1.5 rounded-lg shadow font-bengali">
              <i class="fa-regular fa-eye mr-1"></i>বিস্তারিত
            </span>
          </div>
        </div>

        <div class="p-3 sm:p-4 flex flex-col flex-1 gap-2">
          <div>
            <span class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">${product.category}</span>
            <h3 class="text-xs sm:text-sm font-bold text-slate-900 line-clamp-2 hover:text-blue-600 transition cursor-pointer mt-0.5"
              onclick="openProductModal('${product.id}')">${escapeHtml(product.name)}</h3>
            <div class="flex items-center gap-1 mt-1">
              <i class="fa-solid fa-star text-amber-400 text-xs"></i>
              <span class="text-xs font-bold text-slate-800">${product.rating}</span>
              <span class="text-xs text-slate-400">(${product.reviewsCount})</span>
            </div>
          </div>

          <div class="mt-auto pt-2 border-t border-slate-100">
            <div class="flex items-baseline gap-1.5 mb-2.5">
              <span class="text-base sm:text-xl font-black text-slate-950">${cur}${product.price.toLocaleString()}</span>
              ${product.originalPrice > product.price
                ? `<span class="text-xs text-slate-400 line-through">${cur}${product.originalPrice.toLocaleString()}</span>`
                : ''}
            </div>
            <div class="grid grid-cols-2 gap-1.5">
              <button onclick="quickAddToCart('${product.id}')"
                class="py-2 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-bold transition flex items-center justify-center gap-1 font-bengali">
                <i class="fa-solid fa-bag-shopping text-xs"></i>
                <span class="hidden xs:inline">ব্যাগে</span>
              </button>
              <button onclick="quickBuy('${product.id}')"
                class="py-2 px-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition flex items-center justify-center gap-1 font-bengali active:scale-95">
                <span>অর্ডার</span>
                <i class="fa-solid fa-arrow-right text-[10px]"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function resetFilters() {
  state.selectedCategory = 'All';
  state.searchQuery = '';
  const si = document.getElementById('searchInput');
  const ms = document.getElementById('mobileSearchInput');
  if (si) si.value = '';
  if (ms) ms.value = '';
  const cb = document.getElementById('clearSearchBtn');
  if (cb) cb.classList.add('hidden');
  renderCategories();
  fetchProducts();
}

// =================== SEARCH & SORT ===================
function setupEventListeners() {
  const searchInput = document.getElementById('searchInput');
  const mobileSearch = document.getElementById('mobileSearchInput');
  const clearBtn = document.getElementById('clearSearchBtn');
  const sortSelect = document.getElementById('sortSelect');

  let debounce;
  const handleSearch = (val) => {
    state.searchQuery = val.trim();
    if (clearBtn) clearBtn.classList.toggle('hidden', !state.searchQuery);
    clearTimeout(debounce);
    debounce = setTimeout(() => fetchProducts(), 300);
  };

  if (searchInput) {
    searchInput.addEventListener('input', e => {
      if (mobileSearch) mobileSearch.value = e.target.value;
      handleSearch(e.target.value);
    });
  }

  if (mobileSearch) {
    mobileSearch.addEventListener('input', e => {
      if (searchInput) searchInput.value = e.target.value;
      handleSearch(e.target.value);
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      if (mobileSearch) mobileSearch.value = '';
      clearBtn.classList.add('hidden');
      handleSearch('');
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', e => {
      state.sortBy = e.target.value;
      renderProducts();
    });
  }

  // Close modals with Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      closeProductModal();
      toggleCartDrawer(false);
      closeCheckoutModal();
      closeTrackModal();
      closeInvoiceModal();
      closeAdminModal();
    }
  });
}

// =================== PRODUCT MODAL ===================
function openProductModal(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  state.activeModalProduct = product;
  state.modalQuantity = 1;
  state.modalSelectedColor = product.variants?.colors?.[0] || null;
  state.modalSelectedSize = product.variants?.sizes?.[0] || null;

  const modal = document.getElementById('productModal');
  document.getElementById('modalProductImage').src = product.image;
  document.getElementById('modalProductImage').alt = product.name;
  document.getElementById('modalProductName').innerText = product.name;
  document.getElementById('modalProductCategory').innerText = product.category;
  document.getElementById('modalProductPrice').innerText = `${state.settings.currency}${product.price.toLocaleString()}`;

  const origEl = document.getElementById('modalProductOriginalPrice');
  const discEl = document.getElementById('modalDiscountBadge');
  if (product.originalPrice > product.price) {
    origEl.innerText = `${state.settings.currency}${product.originalPrice.toLocaleString()}`;
    const pct = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
    discEl.innerText = `-${pct}% ছাড়`;
    origEl.classList.remove('hidden');
    discEl.classList.remove('hidden');
  } else {
    origEl.classList.add('hidden');
    discEl.classList.add('hidden');
  }

  const badgeEl = document.getElementById('modalProductBadge');
  if (product.badge) {
    badgeEl.innerText = product.badge;
    badgeEl.classList.remove('hidden');
  } else {
    badgeEl.classList.add('hidden');
  }

  document.getElementById('modalProductDescription').innerText = product.description || '';
  document.getElementById('modalQtyDisplay').innerText = '1';

  // Variants
  const vc = document.getElementById('modalVariantContainer');
  let html = '';

  if (product.variants?.colors?.length > 0) {
    html += `
      <div>
        <label class="block text-[11px] font-bold text-slate-700 mb-1.5 font-bengali">রং বেছে নিন:</label>
        <div class="flex flex-wrap gap-1.5" id="modalColorList">
          ${product.variants.colors.map((c, i) => `
            <button type="button" onclick="selectModalColor('${c}')"
              class="modal-color-btn px-3 py-1 rounded-lg border text-xs font-semibold transition ${i === 0 ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-400'}"
              data-color="${c}">${c}</button>
          `).join('')}
        </div>
      </div>`;
  }

  if (product.variants?.sizes?.length > 0) {
    html += `
      <div>
        <label class="block text-[11px] font-bold text-slate-700 mb-1.5 font-bengali">সাইজ বেছে নিন:</label>
        <div class="flex flex-wrap gap-1.5" id="modalSizeList">
          ${product.variants.sizes.map((s, i) => `
            <button type="button" onclick="selectModalSize('${s}')"
              class="modal-size-btn px-3 py-1 rounded-lg border text-xs font-semibold transition ${i === 0 ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-400'}"
              data-size="${s}">${s}</button>
          `).join('')}
        </div>
      </div>`;
  }

  vc.innerHTML = html;
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function selectModalColor(color) {
  state.modalSelectedColor = color;
  document.querySelectorAll('.modal-color-btn').forEach(btn => {
    const isSelected = btn.dataset.color === color;
    btn.className = `modal-color-btn px-3 py-1 rounded-lg border text-xs font-semibold transition ${isSelected ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-400'}`;
  });
}

function selectModalSize(size) {
  state.modalSelectedSize = size;
  document.querySelectorAll('.modal-size-btn').forEach(btn => {
    const isSelected = btn.dataset.size === size;
    btn.className = `modal-size-btn px-3 py-1 rounded-lg border text-xs font-semibold transition ${isSelected ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-400'}`;
  });
}

function adjustModalQty(delta) {
  state.modalQuantity = Math.max(1, state.modalQuantity + delta);
  document.getElementById('modalQtyDisplay').innerText = state.modalQuantity;
}

function closeProductModal() {
  const modal = document.getElementById('productModal');
  modal.classList.add('hidden');
  modal.style.display = '';
  state.activeModalProduct = null;
}

function getSelectedVariant() {
  const parts = [];
  if (state.modalSelectedColor) parts.push(state.modalSelectedColor);
  if (state.modalSelectedSize) parts.push(state.modalSelectedSize);
  return parts.join(' / ');
}

function addModalToCart() {
  if (!state.activeModalProduct) return;
  addToCart(state.activeModalProduct, state.modalQuantity, getSelectedVariant());
  closeProductModal();
  toggleCartDrawer(true);
}

function directBuyFromModal() {
  if (!state.activeModalProduct) return;
  addToCart(state.activeModalProduct, state.modalQuantity, getSelectedVariant());
  closeProductModal();
  openCheckoutModal();
}

function quickBuy(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  const defaultVar = [product.variants?.colors?.[0], product.variants?.sizes?.[0]].filter(Boolean).join(' / ');
  addToCart(product, 1, defaultVar);
  openCheckoutModal();
}

function quickAddToCart(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  const defaultVar = [product.variants?.colors?.[0], product.variants?.sizes?.[0]].filter(Boolean).join(' / ');
  addToCart(product, 1, defaultVar);
  toggleCartDrawer(true);
}

// =================== CART ===================
function loadCartFromStorage() {
  try {
    const saved = localStorage.getItem('rich_mart_cart');
    if (saved) state.cart = JSON.parse(saved);
  } catch { state.cart = []; }
}

function saveCartToStorage() {
  localStorage.setItem('rich_mart_cart', JSON.stringify(state.cart));
}

function addToCart(product, quantity = 1, variant = '') {
  const key = `${product.id}_${variant}`;
  const existing = state.cart.find(i => i.key === key);
  if (existing) {
    existing.quantity += quantity;
  } else {
    state.cart.push({ key, id: product.id, name: product.name, price: product.price, image: product.image, selectedVariant: variant, quantity });
  }
  saveCartToStorage();
  updateCartUI();
}

function updateCartQuantity(key, delta) {
  const item = state.cart.find(i => i.key === key);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) state.cart = state.cart.filter(i => i.key !== key);
  saveCartToStorage();
  updateCartUI();
}

function removeFromCart(key) {
  state.cart = state.cart.filter(i => i.key !== key);
  saveCartToStorage();
  updateCartUI();
}

function updateCartDeliveryArea(area) {
  state.deliveryArea = area;
  updateCartUI();
}

function calcCartTotals() {
  const subtotal = state.cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const freeThreshold = state.settings.freeDeliveryThreshold || 2000;
  let deliveryFee = state.deliveryArea === 'inside_dhaka'
    ? (state.settings.deliveryInsideDhaka || 70)
    : (state.settings.deliveryOutsideDhaka || 130);
  const isFree = subtotal > 0 && subtotal >= freeThreshold;
  if (isFree) deliveryFee = 0;
  return { subtotal, deliveryFee, isFree, grandTotal: subtotal + (state.cart.length > 0 ? deliveryFee : 0), freeThreshold };
}

function updateCartUI() {
  const { subtotal, deliveryFee, isFree, grandTotal, freeThreshold } = calcCartTotals();
  const totalCount = state.cart.reduce((s, i) => s + i.quantity, 0);
  const cur = state.settings.currency;

  // Header badges
  setInnerText('cartCountBadge', totalCount);
  setInnerText('cartTotalBadge', `${cur}${grandTotal.toLocaleString()}`);
  setInnerText('cartDrawerCount', totalCount);

  // Free delivery progress
  if (isFree) {
    setInnerText('freeDeliveryMsg', 'অভিনন্দন! আপনি ফ্রি ডেলিভারি পাচ্ছেন 🎉');
    setInnerText('freeDeliveryRemaining', 'FREE');
    const bar = document.getElementById('freeDeliveryProgressBar');
    if (bar) bar.style.width = '100%';
  } else {
    const diff = Math.max(0, freeThreshold - subtotal);
    const pct = Math.min(100, Math.round((subtotal / freeThreshold) * 100));
    setInnerText('freeDeliveryMsg', `আর ৳${diff.toLocaleString()} শপিং করলেই ফ্রি ডেলিভারি!`);
    setInnerText('freeDeliveryRemaining', `${pct}%`);
    const bar = document.getElementById('freeDeliveryProgressBar');
    if (bar) bar.style.width = `${pct}%`;
  }

  // Price breakdown
  setInnerText('cartSubtotalText', `${cur}${subtotal.toLocaleString()}`);
  setInnerText('cartDeliveryText', isFree ? 'ফ্রি (৳০)' : `${cur}${deliveryFee}`);
  setInnerText('cartTotalText', `${cur}${grandTotal.toLocaleString()}`);

  // Show/hide empty vs footer
  const listEl = document.getElementById('cartItemsList');
  const emptyEl = document.getElementById('emptyCartView');
  const footerEl = document.getElementById('cartFooter');

  if (state.cart.length === 0) {
    if (listEl) listEl.innerHTML = '';
    if (emptyEl) { emptyEl.classList.remove('hidden'); emptyEl.style.display = 'flex'; }
    if (footerEl) footerEl.classList.add('hidden');
    return;
  }

  if (emptyEl) { emptyEl.classList.add('hidden'); emptyEl.style.display = ''; }
  if (footerEl) footerEl.classList.remove('hidden');

  if (listEl) {
    listEl.innerHTML = state.cart.map(item => `
      <div class="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
        <img src="${item.image}" alt="${escapeHtml(item.name)}" class="w-14 h-14 rounded-xl object-cover shrink-0 bg-white border border-slate-200">
        <div class="flex-1 min-w-0">
          <h4 class="text-xs font-bold text-slate-900 truncate">${escapeHtml(item.name)}</h4>
          ${item.selectedVariant ? `<p class="text-[10px] text-blue-600 font-semibold mt-0.5">${item.selectedVariant}</p>` : ''}
          <p class="text-xs font-extrabold text-slate-800 mt-1">${cur}${item.price.toLocaleString()}</p>
        </div>
        <div class="flex flex-col items-end gap-2 shrink-0">
          <button onclick="removeFromCart('${item.key}')" class="text-slate-400 hover:text-red-500 transition" title="Remove">
            <i class="fa-regular fa-trash-can text-xs"></i>
          </button>
          <div class="flex items-center border border-slate-200 bg-white rounded-lg overflow-hidden">
            <button onclick="updateCartQuantity('${item.key}', -1)" class="w-6 h-6 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">-</button>
            <span class="w-7 text-center text-xs font-bold text-slate-900">${item.quantity}</span>
            <button onclick="updateCartQuantity('${item.key}', 1)" class="w-6 h-6 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">+</button>
          </div>
        </div>
      </div>
    `).join('');
  }
}

function toggleCartDrawer(show) {
  const drawer = document.getElementById('cartDrawer');
  if (show) {
    drawer.classList.remove('hidden');
    updateCartUI();
  } else {
    drawer.classList.add('hidden');
  }
}

// =================== CHECKOUT ===================
function openCheckoutModal() {
  if (state.cart.length === 0) {
    alert('আপনার ব্যাগ খালি। প্রথমে পণ্য যোগ করুন।');
    return;
  }
  toggleCartDrawer(false);
  recalcCheckoutTotal();

  // Sync area radio
  document.querySelectorAll('input[name="checkoutArea"]').forEach(r => {
    r.checked = r.value === state.deliveryArea;
  });

  const modal = document.getElementById('checkoutModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function recalcCheckoutTotal() {
  const { grandTotal } = calcCartTotals();
  setInnerText('checkoutItemCount', `${state.cart.reduce((s, i) => s + i.quantity, 0)}টি`);
  setInnerText('checkoutTotalAmount', `${state.settings.currency}${grandTotal.toLocaleString()}`);
}

function closeCheckoutModal() {
  const modal = document.getElementById('checkoutModal');
  modal.classList.add('hidden');
  modal.style.display = '';
}

async function handlePlaceOrder(e) {
  e.preventDefault();

  const name = document.getElementById('customerNameInput').value.trim();
  const phone = document.getElementById('customerPhoneInput').value.trim();
  const address = document.getElementById('customerAddressInput').value.trim();
  const notes = document.getElementById('customerNotesInput').value.trim();
  const submitBtn = document.getElementById('submitOrderBtn');

  if (!name || !phone || !address) {
    alert('দয়া করে নাম, ফোন নম্বর এবং ঠিকানা দিন।');
    return;
  }

  if (phone.replace(/\D/g, '').length < 10) {
    alert('সঠিক মোবাইল নম্বর দিন।');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i>অর্ডার প্রস্তুত হচ্ছে...';

  try {
    const payload = {
      customerName: name,
      customerPhone: phone,
      deliveryAddress: address,
      area: state.deliveryArea,
      notes,
      paymentMethod: 'Cash on Delivery (ক্যাশ অন ডেলিভারি)',
      items: state.cart.map(item => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        selectedVariant: item.selectedVariant
      }))
    };

    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (!data.success) {
      alert('অর্ডার সাবমিট করতে সমস্যা: ' + (data.error || 'Unknown error'));
      return;
    }

    // Clear cart & form
    state.cart = [];
    saveCartToStorage();
    updateCartUI();
    document.getElementById('checkoutForm').reset();
    closeCheckoutModal();

    // Direct redirect to WhatsApp with order receipt
    window.location.href = data.waUrl;

  } catch (err) {
    console.error('Order error:', err);
    alert('সার্ভারে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<span>অর্ডার কনফার্ম করুন (Place Order)</span> <i class="fa-solid fa-arrow-right text-xs"></i>';
  }
}

// =================== ORDER TRACKING ===================
function openTrackModal() {
  const modal = document.getElementById('trackModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function closeTrackModal() {
  const modal = document.getElementById('trackModal');
  modal.classList.add('hidden');
  modal.style.display = '';
  const container = document.getElementById('trackResultContainer');
  if (container) { container.classList.add('hidden'); container.innerHTML = ''; }
}

async function handleTrackOrder(e) {
  e.preventDefault();
  const query = document.getElementById('trackQueryInput').value.trim();
  const btn = document.getElementById('trackSubmitBtn');
  const container = document.getElementById('trackResultContainer');
  if (!query) return;

  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

  try {
    const res = await fetch(`/api/orders/track?query=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (!data.success || !data.orders?.length) {
      container.innerHTML = `
        <div class="p-4 rounded-2xl bg-red-50 border border-red-200 text-center text-xs text-red-600 font-bengali">
          <i class="fa-solid fa-circle-exclamation text-base mb-1 block"></i>
          ${data.error || 'কোনো অর্ডার পাওয়া যায়নি। আইডি বা ফোন নম্বর চেক করুন।'}
        </div>`;
      container.classList.remove('hidden');
      return;
    }

    const steps = [
      { label: 'অর্ডার গৃহীত', key: 'Pending', icon: 'fa-clipboard-check' },
      { label: 'কনফার্মড', key: 'Confirmed', icon: 'fa-phone-volume' },
      { label: 'শিপড', key: 'Shipped', icon: 'fa-truck-fast' },
      { label: 'ডেলিভার্ড', key: 'Delivered', icon: 'fa-box-open' }
    ];
    const statusIdx = { Pending: 0, Confirmed: 1, Shipped: 2, Delivered: 3, Cancelled: -1 };

    container.innerHTML = data.orders.map(order => {
      const curIdx = statusIdx[order.status] ?? 0;
      const dateStr = new Date(order.createdAt).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' });

      return `
        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-3 font-bengali">
          <div class="flex justify-between items-center pb-2 border-b border-slate-200">
            <div>
              <span class="font-black text-slate-900 font-mono">#${order.id}</span>
              <p class="text-[10px] text-slate-500 mt-0.5">${dateStr}</p>
            </div>
            <span class="px-2.5 py-1 rounded-full text-[11px] font-bold ${order.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'}">
              ${order.status}
            </span>
          </div>

          ${order.status === 'Cancelled'
            ? `<div class="p-2 rounded-xl bg-red-50 text-red-600 text-center font-bold text-xs">অর্ডারটি বাতিল করা হয়েছে।</div>`
            : `<div class="grid grid-cols-4 gap-1 text-center py-1">
                ${steps.map((st, idx) => {
                  const done = idx <= curIdx;
                  return `
                    <div class="flex flex-col items-center gap-1">
                      <div class="w-7 h-7 rounded-full flex items-center justify-center text-xs ${done ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-400'}">
                        <i class="fa-solid ${st.icon}"></i>
                      </div>
                      <span class="text-[9px] leading-tight ${done ? 'font-bold text-slate-900' : 'text-slate-400'}">${st.label}</span>
                    </div>`;
                }).join('')}
              </div>`
          }

          <div class="bg-white p-3 rounded-xl border border-slate-200 space-y-1.5 text-[11px]">
            <p><strong>গ্রাহক:</strong> ${order.customerName} (${order.customerPhoneMasked})</p>
            <p><strong>ঠিকানা:</strong> ${order.deliveryAddress}</p>
            <p><strong>মোট বিল:</strong> <span class="font-bold text-emerald-700">${state.settings.currency}${order.total}</span> (${order.paymentMethod})</p>
            <div class="pt-1.5 border-t border-slate-100 text-slate-500">
              ${order.items.map(i => `• ${i.quantity}x ${i.name}${i.selectedVariant ? ` (${i.selectedVariant})` : ''}`).join('<br>')}
            </div>
          </div>

          <a href="https://wa.me/${state.settings.whatsappNumber}?text=${encodeURIComponent(`Hello Rich Mart, আমার অর্ডার #${order.id} এর স্ট্যাটাস জানতে চাই।`)}"
            target="_blank"
            class="w-full py-2.5 rounded-xl bg-[#25D366] text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#128C7E] transition">
            <i class="fa-brands fa-whatsapp text-sm"></i>
            <span>WhatsApp-এ চ্যাট করুন</span>
          </a>
        </div>`;
    }).join('');

    container.classList.remove('hidden');
  } catch (err) {
    container.innerHTML = `<div class="p-3 text-center text-xs text-red-500">ট্র্যাকিং লোড করতে সমস্যা হয়েছে।</div>`;
    container.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.innerHTML = 'খুঁজুন';
  }
}

// =================== ADMIN ===================
function openAdminModal() {
  const modal = document.getElementById('adminModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
  if (state.adminPin) {
    loadAdminDashboard();
  } else {
    document.getElementById('adminLoginView').classList.remove('hidden');
    document.getElementById('adminDashboardView').classList.add('hidden');
  }
}

function closeAdminModal() {
  const modal = document.getElementById('adminModal');
  modal.classList.add('hidden');
  modal.style.display = '';
}

async function handleAdminLogin(e) {
  e.preventDefault();
  const pin = document.getElementById('adminPinInput').value;
  const errorEl = document.getElementById('adminLoginError');

  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });
    const data = await res.json();
    if (data.success) {
      state.adminPin = pin;
      localStorage.setItem('rm_admin_pin', pin);
      errorEl.classList.add('hidden');
      loadAdminDashboard();
    } else {
      errorEl.innerText = 'ভুল PIN! আবার চেষ্টা করুন।';
      errorEl.classList.remove('hidden');
    }
  } catch {
    errorEl.innerText = 'লগইন ব্যর্থ।';
    errorEl.classList.remove('hidden');
  }
}

async function loadAdminDashboard() {
  document.getElementById('adminLoginView').classList.add('hidden');
  document.getElementById('adminDashboardView').classList.remove('hidden');
  await loadAdminStats();
  await loadAdminOrders();
  await loadAdminProducts();
  loadAdminSettingsForm();
}

function switchAdminTab(tab) {
  ['orders', 'products', 'settings'].forEach(t => {
    const content = document.getElementById(`adminTab${t.charAt(0).toUpperCase() + t.slice(1)}`);
    const btn = document.getElementById(`tabBtn${t.charAt(0).toUpperCase() + t.slice(1)}`);
    if (content) content.classList.toggle('hidden', t !== tab);
    if (btn) {
      btn.className = t === tab
        ? 'pb-3 border-b-2 border-slate-900 text-slate-900 transition flex items-center gap-1.5 whitespace-nowrap font-bold text-xs'
        : 'pb-3 border-b-2 border-transparent text-slate-500 hover:text-slate-800 transition flex items-center gap-1.5 whitespace-nowrap font-bold text-xs';
    }
  });
}

async function loadAdminStats() {
  try {
    const res = await fetch(`/api/analytics?pin=${state.adminPin}`);
    const data = await res.json();
    if (data.success) {
      setInnerText('statTotalOrders', data.stats.totalOrders);
      setInnerText('statTotalRevenue', `${state.settings.currency}${data.stats.totalRevenue.toLocaleString()}`);
      setInnerText('statPendingOrders', data.stats.pendingOrders);
      setInnerText('statDeliveredOrders', data.stats.deliveredOrders);
    }
  } catch (e) { console.warn('Stats error', e); }
}

async function loadAdminOrders() {
  try {
    const res = await fetch(`/api/orders?pin=${state.adminPin}`);
    const data = await res.json();
    if (data.success) {
      state.adminOrders = data.orders;
      renderAdminOrdersTable();
    }
  } catch (e) { console.warn('Orders error', e); }
}

function renderAdminOrdersTable() {
  const tbody = document.getElementById('adminOrdersTableBody');
  if (!tbody) return;

  if (!state.adminOrders.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="p-8 text-center text-slate-400 font-bengali">কোনো অর্ডার নেই</td></tr>`;
    return;
  }

  const statusColors = {
    Pending: 'bg-amber-100 text-amber-800 border border-amber-300',
    Confirmed: 'bg-blue-100 text-blue-800 border border-blue-300',
    Shipped: 'bg-purple-100 text-purple-800 border border-purple-300',
    Delivered: 'bg-emerald-100 text-emerald-800 border border-emerald-300',
    Cancelled: 'bg-red-100 text-red-800 border border-red-300'
  };

  tbody.innerHTML = state.adminOrders.map(order => {
    const cleanPhone = order.customerPhone.replace(/\D/g, '');
    const waUrl = `https://wa.me/88${cleanPhone.startsWith('88') ? cleanPhone.slice(2) : cleanPhone}?text=${encodeURIComponent(`Hello ${order.customerName}, regarding your order #${order.id}`)}`;

    return `
      <tr class="hover:bg-slate-50 transition">
        <td class="p-3 font-bold font-mono text-emerald-700 text-xs">#${order.id}</td>
        <td class="p-3">
          <p class="font-bold text-slate-900 text-xs">${escapeHtml(order.customerName)}</p>
          <p class="text-[11px] text-slate-500">${order.customerPhone}</p>
          <p class="text-[10px] text-slate-400 max-w-[160px] truncate">${escapeHtml(order.deliveryAddress)}</p>
        </td>
        <td class="p-3 text-xs">
          <span class="font-semibold">${order.items.length} পণ্য</span>
          <p class="text-[10px] text-slate-400 max-w-[150px] truncate">${order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}</p>
        </td>
        <td class="p-3 font-extrabold text-slate-900 text-xs">${state.settings.currency}${order.total.toLocaleString()}</td>
        <td class="p-3">
          <select onchange="updateOrderStatus('${order.id}', this.value)"
            class="px-2 py-1 rounded-md text-[11px] font-bold border ${statusColors[order.status] || 'bg-slate-100 text-slate-700'} outline-none cursor-pointer">
            ${['Pending','Confirmed','Shipped','Delivered','Cancelled'].map(s =>
              `<option value="${s}" ${order.status === s ? 'selected' : ''}>${s}</option>`
            ).join('')}
          </select>
        </td>
        <td class="p-3">
          <div class="flex items-center gap-1.5">
            <button onclick="copyCourierInfo('${order.id}')"
              class="w-7 h-7 rounded-lg bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center text-xs transition" title="কুরিয়ার তথ্য কপি করুন">
              <i class="fa-regular fa-clipboard"></i>
            </button>
            <a href="${waUrl}" target="_blank"
              class="w-7 h-7 rounded-lg bg-[#25D366] hover:bg-[#128C7E] text-white flex items-center justify-center text-xs transition" title="WhatsApp">
              <i class="fa-brands fa-whatsapp"></i>
            </a>
            <a href="tel:${order.customerPhone}"
              class="w-7 h-7 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center text-xs transition" title="Call">
              <i class="fa-solid fa-phone"></i>
            </a>
            <button onclick="openInvoiceModal('${order.id}')"
              class="w-7 h-7 rounded-lg bg-slate-900 hover:bg-emerald-600 text-white flex items-center justify-center text-xs transition" title="Invoice">
              <i class="fa-solid fa-print"></i>
            </button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: state.adminPin, status: newStatus })
    });
    const data = await res.json();
    if (data.success) {
      await loadAdminStats();
      await loadAdminOrders();
    }
  } catch { alert('Status update failed'); }
}

async function loadAdminProducts() {
  setInnerText('adminProductCount', state.products.length);
  const list = document.getElementById('adminProductList');
  if (!list) return;

  list.innerHTML = state.products.map(p => `
    <div class="bg-white p-3 rounded-xl border border-slate-200 flex gap-3 shadow-sm">
      <img src="${p.image}" class="w-14 h-14 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-100">
      <div class="flex-1 min-w-0">
        <h5 class="text-xs font-bold text-slate-900 truncate">${escapeHtml(p.name)}</h5>
        <p class="text-[10px] text-slate-500">${p.category} | Stock: ${p.stock}</p>
        <p class="text-xs font-extrabold text-emerald-700 mt-1">${state.settings.currency}${p.price}</p>
        <div class="flex gap-2 mt-2">
          <button onclick="openEditProductModal('${p.id}')" class="text-[10px] font-bold text-blue-600 hover:underline">Edit</button>
          <span class="text-slate-300">|</span>
          <button onclick="handleDeleteProduct('${p.id}')" class="text-[10px] font-bold text-red-600 hover:underline">Delete</button>
        </div>
      </div>
    </div>
  `).join('');
}

function openAddProductModal() {
  document.getElementById('addEditModalTitle').innerText = 'নতুন পণ্য যোগ করুন';
  document.getElementById('editProductId').value = '';
  document.getElementById('productForm').reset();
  const modal = document.getElementById('addEditProductModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function openEditProductModal(id) {
  const p = state.products.find(item => item.id === id);
  if (!p) return;

  document.getElementById('addEditModalTitle').innerText = 'পণ্য সম্পাদনা';
  document.getElementById('editProductId').value = p.id;
  document.getElementById('prodTitleInput').value = p.name;
  document.getElementById('prodCategoryInput').value = p.category;
  document.getElementById('prodBadgeInput').value = p.badge || '';
  document.getElementById('prodPriceInput').value = p.price;
  document.getElementById('prodOriginalPriceInput').value = p.originalPrice || '';
  document.getElementById('prodStockInput').value = p.stock || 10;
  document.getElementById('prodImageInput').value = p.image;
  document.getElementById('prodColorsInput').value = p.variants?.colors?.join(', ') || '';
  document.getElementById('prodSizesInput').value = p.variants?.sizes?.join(', ') || '';
  document.getElementById('prodDescInput').value = p.description || '';

  const modal = document.getElementById('addEditProductModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function closeAddProductModal() {
  const modal = document.getElementById('addEditProductModal');
  modal.classList.add('hidden');
  modal.style.display = '';
}

async function handleProductFormSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('editProductId').value;
  const productData = {
    name: document.getElementById('prodTitleInput').value,
    category: document.getElementById('prodCategoryInput').value,
    badge: document.getElementById('prodBadgeInput').value,
    price: Number(document.getElementById('prodPriceInput').value),
    originalPrice: Number(document.getElementById('prodOriginalPriceInput').value) || Number(document.getElementById('prodPriceInput').value),
    stock: Number(document.getElementById('prodStockInput').value),
    image: document.getElementById('prodImageInput').value,
    colors: document.getElementById('prodColorsInput').value,
    sizes: document.getElementById('prodSizesInput').value,
    description: document.getElementById('prodDescInput').value
  };

  try {
    const res = await fetch(id ? `/api/products/${id}` : '/api/products', {
      method: id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: state.adminPin, product: productData })
    });
    const data = await res.json();
    if (data.success) {
      closeAddProductModal();
      await fetchProducts();
      await loadAdminProducts();
      await loadAdminStats();
    } else {
      alert('Error: ' + data.error);
    }
  } catch { alert('সেভ করতে সমস্যা।'); }
}

async function handleDeleteProduct(id) {
  if (!confirm('এই পণ্যটি মুছে ফেলবেন?')) return;
  try {
    const res = await fetch(`/api/products/${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: state.adminPin })
    });
    const data = await res.json();
    if (data.success) {
      await fetchProducts();
      await loadAdminProducts();
      await loadAdminStats();
    }
  } catch { alert('Delete failed'); }
}

function loadAdminSettingsForm() {
  document.getElementById('settingStoreName').value = state.settings.storeName || '';
  document.getElementById('settingWhatsapp').value = state.settings.whatsappNumber || '';
  document.getElementById('settingPhone').value = state.settings.phone || '';
  document.getElementById('settingInsideDhaka').value = state.settings.deliveryInsideDhaka || 70;
  document.getElementById('settingOutsideDhaka').value = state.settings.deliveryOutsideDhaka || 130;
  document.getElementById('settingFreeThreshold').value = state.settings.freeDeliveryThreshold || 2000;
  document.getElementById('settingFacebook').value = state.settings.facebookUrl || '';
}

async function handleSaveSettings(e) {
  e.preventDefault();
  const newPinVal = document.getElementById('settingNewPin')?.value.trim();
  const newSettings = {
    storeName: document.getElementById('settingStoreName').value,
    whatsappNumber: document.getElementById('settingWhatsapp').value,
    phone: document.getElementById('settingPhone').value,
    deliveryInsideDhaka: Number(document.getElementById('settingInsideDhaka').value),
    deliveryOutsideDhaka: Number(document.getElementById('settingOutsideDhaka').value),
    freeDeliveryThreshold: Number(document.getElementById('settingFreeThreshold').value),
    facebookUrl: document.getElementById('settingFacebook').value
  };

  if (newPinVal) {
    newSettings.newPin = newPinVal;
  }

  try {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: state.adminPin, newSettings })
    });
    const data = await res.json();
    if (data.success) {
      state.settings = { ...state.settings, ...newSettings };
      delete state.settings.newPin;
      if (newPinVal) {
        state.adminPin = newPinVal;
        localStorage.setItem('rm_admin_pin', newPinVal);
        const pinInput = document.getElementById('settingNewPin');
        if (pinInput) pinInput.value = '';
        alert('সেটিংস ও নতুন PIN সফলভাবে সংরক্ষিত হয়েছে!');
      } else {
        alert('সেটিংস সফলভাবে সেভ হয়েছে!');
      }
      applySettingsToDOM();
    } else {
      alert('Error: ' + data.error);
    }
  } catch { alert('সেটিংস সেভ করতে সমস্যা।'); }
}

function copyCourierInfo(orderId) {
  const order = state.adminOrders.find(o => o.id === orderId);
  if (!order) return;
  const areaName = order.area === 'inside_dhaka' ? 'ঢাকা সিটি' : 'ঢাকার বাইরে';
  const text = `নাম: ${order.customerName}\nমোবাইল: ${order.customerPhone}\nঠিকানা: ${order.deliveryAddress} (${areaName})\nকালেকশন/COD: ${order.total} টাকা\nপণ্য: ${order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}`;

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      alert(`কুরিয়ারের জন্য ডেলিভারি তথ্য কপি সম্পন্ন! ✓\n\n${text}`);
    }).catch(() => {
      prompt('নিচের তথ্য কপি করে কুরিয়ার প্যানেলে পেস্ট করুন:', text);
    });
  } else {
    prompt('নিচের তথ্য কপি করে কুরিয়ার প্যানেলে পেস্ট করুন:', text);
  }
}

// =================== INVOICE ===================
function openInvoiceModal(orderId) {
  const order = state.adminOrders.find(o => o.id === orderId);
  if (!order) return;

  const areaText = order.area === 'inside_dhaka' ? 'Inside Dhaka (ঢাকা সিটি)' : 'Outside Dhaka (ঢাকার বাইরে)';
  const dateStr = new Date(order.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const cur = state.settings.currency;

  document.getElementById('printableInvoiceArea').innerHTML = `
    <div class="border-2 border-slate-900 rounded-2xl p-6 bg-white space-y-5">
      <div class="flex justify-between items-start pb-4 border-b-2 border-slate-900">
        <div class="flex items-center gap-3">
          <img src="/logo.jpg" alt="Rich Mart" class="w-12 h-12 rounded-xl object-cover border border-slate-300">
          <div>
            <h2 class="text-xl font-extrabold uppercase tracking-wide text-slate-900">${escapeHtml(state.settings.storeName)}</h2>
            <p class="text-xs text-slate-600">Online Sell BD | Hotline: ${state.settings.phone}</p>
          </div>
        </div>
        <div class="text-right">
          <div class="inline-block bg-slate-900 text-white font-mono font-black text-sm px-3 py-1 rounded">ORDER #${order.id}</div>
          <p class="text-xs text-slate-500 mt-1">Date: ${dateStr}</p>
          <p class="text-xs font-bold text-emerald-700">Status: ${order.status}</p>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-4 text-xs">
        <div class="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
          <p class="font-extrabold text-slate-500 uppercase tracking-wider text-[10px] mb-2">Delivered To:</p>
          <p class="font-bold text-slate-900">${escapeHtml(order.customerName)}</p>
          <p class="font-bold text-slate-700">${order.customerPhone}</p>
          <p class="text-slate-600 mt-1">${escapeHtml(order.deliveryAddress)}</p>
          <p class="text-slate-500 mt-1">Area: ${areaText}</p>
          ${order.notes ? `<p class="text-amber-700 mt-1 italic">Note: ${escapeHtml(order.notes)}</p>` : ''}
        </div>
        <div class="bg-emerald-50 p-3.5 rounded-xl border border-emerald-200">
          <p class="font-extrabold text-emerald-800 uppercase tracking-wider text-[10px] mb-2">COD Collection:</p>
          <h3 class="text-2xl font-black text-emerald-800">${cur}${order.total.toLocaleString()}</h3>
          <p class="text-[11px] text-slate-600 mt-1">${order.paymentMethod}</p>
          <p class="text-[10px] text-slate-500 mt-2 pt-2 border-t border-emerald-200">Collect exact cash on delivery.</p>
        </div>
      </div>

      <div class="border border-slate-200 rounded-xl overflow-hidden">
        <table class="w-full text-left text-xs">
          <thead class="bg-slate-100 uppercase text-[10px] text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th class="p-2.5">Item</th>
              <th class="p-2.5 text-center">Qty</th>
              <th class="p-2.5 text-right">Price</th>
              <th class="p-2.5 text-right">Total</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            ${order.items.map(item => `
              <tr>
                <td class="p-2.5 font-bold">${escapeHtml(item.name)}${item.selectedVariant ? ` <span class="text-emerald-700 font-normal">(${item.selectedVariant})</span>` : ''}</td>
                <td class="p-2.5 text-center">${item.quantity}</td>
                <td class="p-2.5 text-right">${cur}${item.price.toLocaleString()}</td>
                <td class="p-2.5 text-right font-bold">${cur}${(item.quantity * item.price).toLocaleString()}</td>
              </tr>`).join('')}
          </tbody>
          <tfoot class="bg-slate-50 font-bold border-t border-slate-200 text-xs">
            <tr><td colspan="3" class="p-2 text-right">Subtotal:</td><td class="p-2 text-right">${cur}${order.subtotal.toLocaleString()}</td></tr>
            <tr><td colspan="3" class="p-2 text-right">Delivery:</td><td class="p-2 text-right">${cur}${order.deliveryFee}</td></tr>
            <tr class="text-sm text-slate-900 border-t border-slate-300">
              <td colspan="3" class="p-2.5 text-right font-black uppercase">Net Cash to Collect:</td>
              <td class="p-2.5 text-right font-black text-emerald-700">${cur}${order.total.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div class="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-200">
        Thank you for shopping with ${escapeHtml(state.settings.storeName)}! WhatsApp: ${state.settings.phone}
      </div>
    </div>`;

  const modal = document.getElementById('invoiceModal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
}

function closeInvoiceModal() {
  const modal = document.getElementById('invoiceModal');
  modal.classList.add('hidden');
  modal.style.display = '';
}
