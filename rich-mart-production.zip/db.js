const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'data', 'db.json');

// Default initial data
const DEFAULT_DATA = {
  "settings": {
    "storeName": "Rich Mart Fashion",
    "tagline": "Style That Speaks, Quality That Lasts | Online sell BD",
    "phone": "01606609110",
    "whatsappNumber": "8801606609110",
    "currency": "৳",
    "deliveryInsideDhaka": 70,
    "deliveryOutsideDhaka": 130,
    "freeDeliveryThreshold": 2000,
    "bkashNumber": "01606609110 (Send Money / Personal)",
    "facebookUrl": "https://www.facebook.com/people/Rich-Mart/61565633054658/",
    "adminPin": "1234"
  },
  "products": [
    {
      "id": "prod-fb-1",
      "name": "Luxury Campus Cuban Collar Casual Shirt (Beige)",
      "category": "Men's Fashion",
      "price": 850,
      "originalPrice": 1250,
      "image": "/products/product_2.jpg",
      "description": "Luxury Campus প্রিমিয়াম ক্যাজুয়াল কিউবান কলার শার্ট। ১০০% আরামদায়ক সফট কটন ফেব্রিক, ফর্মাল ও ক্যাজুয়াল উভয় লুকে চমৎকার মানানসই। অরিজিনাল শপ কালেকশন।",
      "stock": 23,
      "rating": 4.9,
      "reviewsCount": 38,
      "badge": "Hot Seller",
      "variants": {
        "colors": [
          "Beige / Khaki"
        ],
        "sizes": [
          "M (Chest 38)",
          "L (Chest 40)",
          "XL (Chest 42)"
        ]
      }
    },
    {
      "id": "prod-fb-2",
      "name": "Luxury Campus Floral Print Casual Shirt (White)",
      "category": "Men's Fashion",
      "price": 890,
      "originalPrice": 1300,
      "image": "/products/product_3.jpg",
      "description": "ট্রেন্ডি ফ্লোরাল প্রিন্ট ক্যাজুয়াল শার্ট। লাইটওয়েট ব্রিদেবল ফেব্রিক, গ্রীষ্ম ও যেকোনো ক্যাজুয়াল আউটিংয়ে আরামদায়ক পরিধানের জন্য বেস্ট চয়েস।",
      "stock": 20,
      "rating": 4.8,
      "reviewsCount": 29,
      "badge": "Trending",
      "variants": {
        "colors": [
          "Monochrome Floral"
        ],
        "sizes": [
          "M",
          "L",
          "XL"
        ]
      }
    },
    {
      "id": "prod-fb-3",
      "name": "Luxury Campus Royal Baroque Gold & Black Printed Shirt",
      "category": "Men's Fashion",
      "price": 950,
      "originalPrice": 1450,
      "image": "/products/product_4.jpg",
      "description": "রয়্যাল ব্যারোক ডিজাইন প্রিমিয়াম প্রিন্টেড শার্ট। জমকালো পার্টি, গেট টুগেদার ও বিশেষ অনুষ্ঠানে আলাদা স্মার্ট লুকের নিশ্চয়তা।",
      "stock": 18,
      "rating": 5,
      "reviewsCount": 45,
      "badge": "Premium",
      "variants": {
        "colors": [
          "Royal Black & Gold"
        ],
        "sizes": [
          "M",
          "L",
          "XL"
        ]
      }
    },
    {
      "id": "prod-fb-4",
      "name": "Luxury Campus Autumn Maroon Floral Designer Shirt",
      "category": "Men's Fashion",
      "price": 890,
      "originalPrice": 1350,
      "image": "/products/product_5.jpg",
      "description": "অটাম কালেকশন মেরুন অ্যান্ড ক্রিম ফ্লোরাল ডিজাইনার শার্ট। প্রিমিয়াম বাটন ফিনিশিং ও কালার গ্যারান্টি।",
      "stock": 22,
      "rating": 4.8,
      "reviewsCount": 21,
      "badge": "New Arrival",
      "variants": {
        "colors": [
          "Maroon & Cream"
        ],
        "sizes": [
          "M",
          "L",
          "XL"
        ]
      }
    },
    {
      "id": "prod-fb-5",
      "name": "Alam's Baby Wear Sky Blue Floral Frock with Lace Bow",
      "category": "Baby & Kids",
      "price": 490,
      "originalPrice": 750,
      "image": "/products/product_6.jpg",
      "description": "আলম'স বেবি ওয়্যার ১০০% পিওর কটন বেবি ফ্রক। বাচ্চাদের সংবেদনশীল ত্বকের জন্য সম্পূর্ণ নিরাপদ, নরম ও আরামদায়ক। সুন্দর লেস ও ফ্রন্ট বো ডিজাইন।",
      "stock": 30,
      "rating": 4.9,
      "reviewsCount": 52,
      "badge": "Best for Baby",
      "variants": {
        "colors": [
          "Sky Blue"
        ],
        "sizes": [
          "0-6 Months",
          "6-12 Months",
          "1-2 Years"
        ]
      }
    },
    {
      "id": "prod-fb-6",
      "name": "Alam's Baby Wear Ruffle Collar Printed Baby Dress (Cream)",
      "category": "Baby & Kids",
      "price": 490,
      "originalPrice": 750,
      "image": "/products/product_7.jpg",
      "description": "রাফেল কলার প্রিন্টেড সফট কটন ফ্রক। কিউট বাটন ফ্রন্ট, বেবিদের দৈনন্দিন ব্যবহার ও উৎসবের জন্য পারফেক্ট।",
      "stock": 28,
      "rating": 4.8,
      "reviewsCount": 34,
      "badge": "Cute Style",
      "variants": {
        "colors": [
          "Cream Peach"
        ],
        "sizes": [
          "0-6 Months",
          "6-12 Months",
          "1-2 Years"
        ]
      }
    },
    {
      "id": "prod-fb-7",
      "name": "Alam's Baby Wear Mint Green Embroidered Floral Frock",
      "category": "Baby & Kids",
      "price": 520,
      "originalPrice": 800,
      "image": "/products/product_8.jpg",
      "description": "হাতে সূক্ষ্ম এমব্রয়ডারি করা মিন্ট গ্রিন বেবি ফ্রক। প্রিমিয়াম কোয়ালিটি এবং শিশুদের জন্য দারুণ আরামদায়ক।",
      "stock": 25,
      "rating": 4.9,
      "reviewsCount": 41,
      "badge": "Hand Work",
      "variants": {
        "colors": [
          "Mint Green"
        ],
        "sizes": [
          "6-12 Months",
          "1-2 Years",
          "2-3 Years"
        ]
      }
    },
    {
      "id": "prod-fb-8",
      "name": "Alam's Baby Wear Colorful Ribbon Bow Soft Cotton Frock",
      "category": "Baby & Kids",
      "price": 480,
      "originalPrice": 720,
      "image": "/products/product_9.jpg",
      "description": "কালারফুল রিবন বো প্রিন্ট কিউট কটন বেবি ফ্রক। নিয়মিত ব্যবহারে অত্যন্ত আরামদায়ক এবং কালার টেকসই।",
      "stock": 35,
      "rating": 4.7,
      "reviewsCount": 27,
      "badge": "Popular",
      "variants": {
        "colors": [
          "White Pastel"
        ],
        "sizes": [
          "0-6 Months",
          "6-12 Months",
          "1-2 Years"
        ]
      }
    },
    {
      "id": "prod-1",
      "name": "Ultra Smart Watch Series 9 with AMOLED Display",
      "category": "Smart Gadgets",
      "price": 2450,
      "originalPrice": 3200,
      "image": "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&q=80",
      "description": "Premium AMOLED Always-On Display, Bluetooth calling, heart rate & SpO2 monitor, waterproof IP68, 7-day battery life.",
      "stock": 35,
      "rating": 4.8,
      "reviewsCount": 42,
      "badge": "Gadget Best Seller",
      "variants": {
        "colors": [
          "Jet Black",
          "Titanium Silver"
        ],
        "sizes": [
          "Standard 49mm"
        ]
      }
    },
    {
      "id": "prod-2",
      "name": "TWS Wireless Earbuds with ANC & Deep Bass",
      "category": "Smart Gadgets",
      "price": 1350,
      "originalPrice": 1950,
      "image": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80",
      "description": "Active Noise Cancellation (ANC), 36-hour total playback with charging case, crystal-clear microphone for calls.",
      "stock": 48,
      "rating": 4.9,
      "reviewsCount": 67,
      "badge": "Top Audio",
      "variants": {
        "colors": [
          "Matte Black",
          "Pearl White"
        ],
        "sizes": []
      }
    }
  ],
  "orders": [
    {
      "id": "RM-2385",
      "customerName": "rthff",
      "customerPhone": "01866597179",
      "deliveryAddress": "barisal",
      "area": "outside_dhaka",
      "notes": "",
      "paymentMethod": "Cash on Delivery (ক্যাশ অন ডেলিভারি)",
      "items": [
        {
          "id": "prod-fb-1",
          "name": "Luxury Campus Cuban Collar Casual Shirt (Beige)",
          "price": 850,
          "quantity": 2,
          "selectedVariant": "Beige / Khaki"
        }
      ],
      "subtotal": 1700,
      "deliveryFee": 130,
      "discount": 0,
      "total": 1830,
      "status": "Pending",
      "whatsappMessageSent": true,
      "createdAt": "2026-11-08T15:03:44.420Z"
    },
    {
      "id": "RM-1021",
      "customerName": "Rahim Ahmed",
      "customerPhone": "01712345678",
      "deliveryAddress": "House 24, Road 5, Dhanmondi, Dhaka",
      "area": "inside_dhaka",
      "notes": "Please deliver before 5 PM",
      "paymentMethod": "Cash on Delivery",
      "items": [
        {
          "id": "prod-fb-1",
          "name": "Luxury Campus Cuban Collar Casual Shirt (Beige)",
          "price": 850,
          "quantity": 2,
          "selectedVariant": "L (Chest 40)"
        }
      ],
      "subtotal": 1700,
      "deliveryFee": 70,
      "discount": 0,
      "total": 1770,
      "status": "Delivered",
      "whatsappMessageSent": true,
      "createdAt": "2026-11-06T14:30:00.000Z"
    },
    {
      "id": "RM-1022",
      "customerName": "Shariful Islam",
      "customerPhone": "01898765432",
      "deliveryAddress": "GEC Circle, Nasirabad, Chattogram",
      "area": "outside_dhaka",
      "notes": "Call me before delivery",
      "paymentMethod": "Cash on Delivery",
      "items": [
        {
          "id": "prod-fb-4",
          "name": "Luxury Campus Autumn Maroon Floral Designer Shirt",
          "price": 890,
          "quantity": 1,
          "selectedVariant": "XL"
        }
      ],
      "subtotal": 890,
      "deliveryFee": 130,
      "discount": 0,
      "total": 1020,
      "status": "Shipped",
      "whatsappMessageSent": true,
      "createdAt": "2026-11-07T09:15:00.000Z"
    }
  ]
};

// Ensure data folder and file exists
function initDB() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DATA, null, 2), 'utf8');
  }
}

function readDB() {
  initDB();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading DB, restoring default:', err);
    return DEFAULT_DATA;
  }
}

function writeDB(data) {
  initDB();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
  initDB,
  readDB,
  writeDB
};

