/**
 * Helper to build high-converting WhatsApp message and link
 */
function buildWhatsAppMessage(order, settings) {
  const currency = settings.currency || '৳';
  
  const itemsText = order.items.map((item, index) => {
    const variant = item.selectedVariant ? ` (${item.selectedVariant})` : '';
    return `${index + 1}. *${item.name}*${variant}\n   Qty: ${item.quantity} × ${currency}${item.price} = ${currency}${item.quantity * item.price}`;
  }).join('\n\n');

  const areaText = order.area === 'inside_dhaka' ? 'Inside Dhaka (ঢাকা সিটি)' : 'Outside Dhaka (ঢাকার বাইরে)';

  const message = 
`🛍️ *NEW ORDER - ${settings.storeName.toUpperCase()}*
━━━━━━━━━━━━━━━━━━━━━━━━
📦 *Order ID:* #${order.id}
📅 *Date:* ${new Date(order.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka', hour12: true })}

👤 *Customer Details:*
• *Name:* ${order.customerName}
• *Phone:* ${order.customerPhone}
• *Address:* ${order.deliveryAddress}
• *Area:* ${areaText}
${order.notes ? `• *Note:* ${order.notes}\n` : ''}
🛒 *Order Items:*
${itemsText}

━━━━━━━━━━━━━━━━━━━━━━━━
💵 *Financial Summary:*
• Subtotal: ${currency}${order.subtotal}
• Delivery Charge: ${currency}${order.deliveryFee}
${order.discount > 0 ? `• Discount: -${currency}${order.discount}\n` : ''}• *Total Payable:* *${currency}${order.total}*
💳 *Payment:* ${order.paymentMethod || 'Cash on Delivery (ক্যাশ অন ডেলিভারি)'}
━━━━━━━━━━━━━━━━━━━━━━━━
দয়া করে আমার অর্ডারটি কনফার্ম করুন। (Please confirm my order.)
ধন্যবাদ! Rich Mart`;

  // Format WhatsApp number to international digits only (e.g. 8801606609110)
  const cleanNumber = (settings.whatsappNumber || '8801606609110').replace(/\D/g, '');
  const waUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;

  return {
    rawMessage: message,
    waUrl
  };
}

module.exports = {
  buildWhatsAppMessage
};

