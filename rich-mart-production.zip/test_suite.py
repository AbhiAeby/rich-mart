import urllib.request
import urllib.parse
import json
import re
import os

BASE_URL = "http://localhost:3000"

print("==================================================")
print("     RICH MART AUTOMATED REAL-WORLD TEST SUITE    ")
print("==================================================")

failures = []

def check(name, condition, details=""):
    if condition:
        print(f" [PASS] {name}")
    else:
        print(f" [FAIL] {name} -> {details}")
        failures.append(f"{name}: {details}")

# ----------------- TEST 1: DOM ID Consistency -----------------
with open("public/app.js", "r", encoding="utf-8") as f:
    js_content = f.read()

with open("public/index.html", "r", encoding="utf-8") as f:
    html_content = f.read()

ids_in_js = set(re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js_content))
ids_in_html = set(re.findall(r'id=["\']([^"\']+)["\']', html_content))

missing_in_html = [i for i in sorted(ids_in_js) if i not in ids_in_html]
check("DOM IDs Consistency (app.js -> index.html)", len(missing_in_html) == 0, f"Missing: {missing_in_html}")

# ----------------- TEST 2: Static Assets -----------------
assets = [
    "/",
    "/logo.jpg",
    "/banner.jpg",
    "/app.js",
    "/videos/product_video_1.mp4",
    "/videos/product_video_2.mp4"
]

for p in range(1, 11):
    assets.append(f"/products/product_{p}.jpg")

for asset in assets:
    try:
        url = BASE_URL + asset
        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=5) as resp:
            check(f"Static Asset Available: {asset}", resp.status == 200, f"Status: {resp.status}")
    except Exception as e:
        check(f"Static Asset Available: {asset}", False, str(e))

# ----------------- TEST 3: Settings API -----------------
try:
    with urllib.request.urlopen(f"{BASE_URL}/api/settings", timeout=5) as r:
        data = json.loads(r.read().decode())
        check("Settings API status", data.get("success") == True)
        settings = data.get("settings", {})
        check("Settings has storeName", "Rich Mart" in settings.get("storeName", ""), f"Actual: {settings.get('storeName')}")
        check("Settings has phone", settings.get("phone") == "01606609110")
        check("Settings has whatsappNumber", "8801606609110" in settings.get("whatsappNumber", ""))
        check("Settings masks adminPin", "adminPin" not in settings)
except Exception as e:
    check("Settings API status", False, str(e))

# ----------------- TEST 4: Admin Login API -----------------
try:
    # Wrong PIN
    req = urllib.request.Request(
        f"{BASE_URL}/api/admin/login",
        data=json.dumps({"pin": "wrong-pin"}).encode(),
        headers={"Content-Type": "application/json"}
    )
    try:
        urllib.request.urlopen(req, timeout=5)
        check("Admin login reject wrong PIN", False, "Expected 401 error")
    except urllib.error.HTTPError as err:
        check("Admin login reject wrong PIN", err.code == 401)

    # Correct PIN
    req_good = urllib.request.Request(
        f"{BASE_URL}/api/admin/login",
        data=json.dumps({"pin": "1234"}).encode(),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req_good, timeout=5) as r:
        res = json.loads(r.read().decode())
        check("Admin login accept correct PIN (1234)", res.get("success") == True)
except Exception as e:
    check("Admin login API", False, str(e))

# ----------------- TEST 5: Products Catalog API & Filters -----------------
try:
    with urllib.request.urlopen(f"{BASE_URL}/api/products", timeout=5) as r:
        res = json.loads(r.read().decode())
        check("Products list success", res.get("success") == True)
        check("Products count >= 10", len(res.get("products", [])) >= 10, f"Count: {len(res.get('products', []))}")
        categories = res.get("categories", [])
        check("Categories present", len(categories) > 1, f"Categories: {categories}")

    # Test Search
    with urllib.request.urlopen(f"{BASE_URL}/api/products?search=shirt", timeout=5) as r:
        res = json.loads(r.read().decode())
        shirts = res.get("products", [])
        check("Search 'shirt' returns items", len(shirts) > 0)
        check("All search results contain 'shirt'", all("shirt" in p["name"].lower() for p in shirts))

    # Test Category filter
    with urllib.request.urlopen(f"{BASE_URL}/api/products?category=Baby%20%26%20Kids", timeout=5) as r:
        res = json.loads(r.read().decode())
        kids = res.get("products", [])
        check("Category filter 'Baby & Kids' works", len(kids) > 0)
        check("Items match category", all(p["category"] == "Baby & Kids" for p in kids))
except Exception as e:
    check("Products API testing", False, str(e))

# ----------------- TEST 6: Real Order Flow with WhatsApp Redirect -----------------
test_order_id = None
try:
    # 6.1 Order inside Dhaka
    payload_inside = {
        "customerName": "QA Automator",
        "customerPhone": "01700112233",
        "deliveryAddress": "Sector 3, Uttara, Dhaka",
        "area": "inside_dhaka",
        "notes": "Testing order inside Dhaka",
        "paymentMethod": "Cash on Delivery",
        "items": [
            {
                "id": "prod-shirt-01",
                "name": "Luxury Campus Cuban Collar Casual Shirt (Beige)",
                "price": 850,
                "quantity": 1,
                "selectedVariant": "Beige / L"
            }
        ]
    }

    req = urllib.request.Request(
        f"{BASE_URL}/api/orders",
        data=json.dumps(payload_inside).encode(),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=5) as r:
        res = json.loads(r.read().decode())
        check("Place Order API success", res.get("success") == True)
        order = res.get("order", {})
        test_order_id = order.get("id")
        check("Order ID generated with format RM-XXXX", bool(re.match(r"^RM-\d+$", test_order_id)), test_order_id)
        check("Inside Dhaka fee applied correctly (850 + 70 = 920)", order.get("total") == 920, f"Total: {order.get('total')}")
        check("WhatsApp redirect URL present", bool(res.get("waUrl")))
        wa_url = res.get("waUrl", "")
        check("WhatsApp URL targets store number 8801606609110", "8801606609110" in wa_url)
        check("WhatsApp message contains order ID", test_order_id in urllib.parse.unquote(wa_url))
        check("WhatsApp message contains customer name", "QA Automator" in urllib.parse.unquote(wa_url))

    # 6.2 Free Delivery Threshold (>= 2000 BDT)
    payload_free = {
        "customerName": "VIP Customer",
        "customerPhone": "01800112233",
        "deliveryAddress": "Mirpur DOHS, Dhaka",
        "area": "outside_dhaka",
        "notes": "Testing free delivery",
        "paymentMethod": "Cash on Delivery",
        "items": [
            {
                "id": "prod-shirt-01",
                "name": "Luxury Campus Cuban Collar Casual Shirt",
                "price": 850,
                "quantity": 3,
                "selectedVariant": "Beige / XL"
            }
        ]
    }
    req_free = urllib.request.Request(
        f"{BASE_URL}/api/orders",
        data=json.dumps(payload_free).encode(),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req_free, timeout=5) as r:
        res_free = json.loads(r.read().decode())
        ord_free = res_free.get("order", {})
        check("Free delivery for order >= 2000 (850*3 = 2550, fee = 0)", ord_free.get("deliveryFee") == 0 and ord_free.get("total") == 2550)
except Exception as e:
    check("Order Placement Flow", False, str(e))

# ----------------- TEST 7: Order Tracking API -----------------
try:
    if test_order_id:
        # Track by Order ID
        with urllib.request.urlopen(f"{BASE_URL}/api/orders/track?query={test_order_id}", timeout=5) as r:
            res = json.loads(r.read().decode())
            check("Track by Order ID success", res.get("success") == True)
            check("Tracking returns correct order", res.get("orders", [{}])[0].get("id") == test_order_id)
            check("Tracking phone number masked for privacy", "****" in res.get("orders", [{}])[0].get("customerPhoneMasked", ""))

        # Track by phone number
        with urllib.request.urlopen(f"{BASE_URL}/api/orders/track?query=01700112233", timeout=5) as r:
            res = json.loads(r.read().decode())
            check("Track by customer Phone number success", res.get("success") == True)
            check("Order found via phone match", any(o["id"] == test_order_id for o in res.get("orders", [])))
except Exception as e:
    check("Order Tracking API", False, str(e))

# ----------------- TEST 8: Admin Management Flow -----------------
try:
    # 8.1 Admin Analytics
    with urllib.request.urlopen(f"{BASE_URL}/api/analytics?pin=1234", timeout=5) as r:
        data = json.loads(r.read().decode())
        check("Admin Analytics success", data.get("success") == True)
        stats = data.get("stats", {})
        check("Total orders tracked", stats.get("totalOrders", 0) > 0)
        check("Total revenue calculated", stats.get("totalRevenue", 0) > 0)

    # 8.2 Admin Status Update
    if test_order_id:
        req_patch = urllib.request.Request(
            f"{BASE_URL}/api/orders/{test_order_id}/status",
            data=json.dumps({"pin": "1234", "status": "Shipped"}).encode(),
            headers={"Content-Type": "application/json"},
            method="PATCH"
        )
        with urllib.request.urlopen(req_patch, timeout=5) as r:
            patch_res = json.loads(r.read().decode())
            check("Admin update order status to Shipped", patch_res.get("order", {}).get("status") == "Shipped")

    # 8.3 Admin Product Add / Edit / Delete lifecycle
    test_prod_payload = {
        "pin": "1234",
        "product": {
            "name": "Temporary Test Product",
            "category": "Men's Fashion",
            "price": 999,
            "originalPrice": 1200,
            "stock": 5,
            "image": "/products/product_1.jpg",
            "badge": "Test",
            "colors": "Red, Blue",
            "sizes": "M, L",
            "description": "Product creation test"
        }
    }
    req_add = urllib.request.Request(
        f"{BASE_URL}/api/products",
        data=json.dumps(test_prod_payload).encode(),
        headers={"Content-Type": "application/json"}
    )
    created_id = None
    with urllib.request.urlopen(req_add, timeout=5) as r:
        add_res = json.loads(r.read().decode())
        check("Admin Add Product success", add_res.get("success") == True)
        created_id = add_res.get("product", {}).get("id")

    if created_id:
        # Edit
        edit_payload = {
            "pin": "1234",
            "product": {
                "name": "Updated Test Product",
                "price": 1050,
                "stock": 8
            }
        }
        req_edit = urllib.request.Request(
            f"{BASE_URL}/api/products/{created_id}",
            data=json.dumps(edit_payload).encode(),
            headers={"Content-Type": "application/json"},
            method="PUT"
        )
        with urllib.request.urlopen(req_edit, timeout=5) as r:
            edit_res = json.loads(r.read().decode())
            check("Admin Edit Product success", edit_res.get("product", {}).get("price") == 1050)

        # Delete
        req_del = urllib.request.Request(
            f"{BASE_URL}/api/products/{created_id}",
            data=json.dumps({"pin": "1234"}).encode(),
            headers={"Content-Type": "application/json"},
            method="DELETE"
        )
        with urllib.request.urlopen(req_del, timeout=5) as r:
            del_res = json.loads(r.read().decode())
            check("Admin Delete Product success", del_res.get("success") == True)

except Exception as e:
    check("Admin Management Flow", False, str(e))

# ----------------- CLEANUP TEST DATA -----------------
try:
    with open("data/db.json", "r", encoding="utf-8") as f:
        db = json.load(f)
    db["orders"] = [o for o in db["orders"] if not o["customerName"].startswith("QA ") and not o["customerName"].startswith("VIP ")]
    with open("data/db.json", "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)
    print("\n [INFO] Cleaned up temporary test orders from DB.")
except Exception as e:
    print(f"\n [WARN] Cleanup warning: {e}")

print("==================================================")
if not failures:
    print(" >>> ALL TESTS PASSED WITH 100% SUCCESS RATE! <<< ")
else:
    print(f" >>> {len(failures)} FAILURES FOUND: <<< ")
    for f in failures:
        print("  *", f)
print("==================================================")
