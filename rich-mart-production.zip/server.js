const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDB, readDB, writeDB } = require('./db');
const { buildWhatsAppMessage } = require('./whatsappHelper');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize DB on start
initDB();

// ==================== STORE SETTINGS ====================
app.get('/api/settings', (req, res) => {
  try {
    const db = readDB();
    // Return settings without sensitive adminPin
    const { adminPin, ...safeSettings } = db.settings;
    res.json({ success: true, settings: safeSettings });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/settings', (req, res) => {
  try {
    const { pin, newSettings } = req.body;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized: Invalid Admin PIN' });
    }

    // Allow updating PIN if newPin is supplied
    if (newSettings && newSettings.newPin && newSettings.newPin.trim()) {
      db.settings.adminPin = newSettings.newPin.trim();
    }
    delete newSettings.newPin;

    db.settings = { ...db.settings, ...newSettings };
    writeDB(db);
    res.json({ success: true, message: 'Settings updated successfully', settings: db.settings });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin verify PIN
app.post('/api/admin/login', (req, res) => {
  try {
    const { pin } = req.body;
    const db = readDB();
    if (pin === db.settings.adminPin) {
      return res.json({ success: true, message: 'Authenticated' });
    }
    return res.status(401).json({ success: false, error: 'Incorrect Admin PIN' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== PRODUCTS ====================
app.get('/api/products', (req, res) => {
  try {
    const db = readDB();
    let products = [...db.products];
    const { category, search } = req.query;

    if (category && category !== 'All') {
      products = products.filter(p => p.category.toLowerCase() === category.toLowerCase());
    }

    if (search) {
      const q = search.toLowerCase();
      products = products.filter(p => 
        p.name.toLowerCase().includes(q) || 
        (p.description && p.description.toLowerCase().includes(q))
      );
    }

    res.json({ success: true, products, categories: ['All', ...new Set(db.products.map(p => p.category))] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/products/:id', (req, res) => {
  try {
    const db = readDB();
    const product = db.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, error: 'Product not found' });
    }
    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Add Product
app.post('/api/products', (req, res) => {
  try {
    const { pin, product } = req.body;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    const newProduct = {
      id: 'prod-' + Date.now(),
      name: product.name,
      category: product.category || 'General',
      price: Number(product.price) || 0,
      originalPrice: Number(product.originalPrice) || Number(product.price),
      image: product.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80',
      description: product.description || '',
      stock: Number(product.stock) || 10,
      rating: 4.8,
      reviewsCount: 1,
      badge: product.badge || '',
      variants: {
        colors: product.colors ? product.colors.split(',').map(s => s.trim()).filter(Boolean) : [],
        sizes: product.sizes ? product.sizes.split(',').map(s => s.trim()).filter(Boolean) : []
      }
    };

    db.products.unshift(newProduct);
    writeDB(db);
    res.status(201).json({ success: true, product: newProduct });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Edit Product
app.put('/api/products/:id', (req, res) => {
  try {
    const { pin, product } = req.body;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    const index = db.products.findIndex(p => p.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Product not found' });
    }

    db.products[index] = {
      ...db.products[index],
      ...product,
      price: Number(product.price),
      originalPrice: Number(product.originalPrice) || Number(product.price),
      stock: Number(product.stock)
    };

    writeDB(db);
    res.json({ success: true, product: db.products[index] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Delete Product
app.delete('/api/products/:id', (req, res) => {
  try {
    const { pin } = req.body;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    db.products = db.products.filter(p => p.id !== req.params.id);
    writeDB(db);
    res.json({ success: true, message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== ORDERS & WHATSAPP ====================

// Customer Checkout / Place Order
app.post('/api/orders', (req, res) => {
  try {
    const { customerName, customerPhone, deliveryAddress, area, notes, items, paymentMethod } = req.body;

    if (!customerName || !customerPhone || !deliveryAddress || !items || !items.length) {
      return res.status(400).json({ success: false, error: 'Please provide all required order details.' });
    }

    const db = readDB();
    const settings = db.settings;

    // Calculate subtotal
    const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
    
    // Calculate delivery fee
    let deliveryFee = area === 'inside_dhaka' ? (settings.deliveryInsideDhaka || 70) : (settings.deliveryOutsideDhaka || 130);
    if (settings.freeDeliveryThreshold && subtotal >= settings.freeDeliveryThreshold) {
      deliveryFee = 0;
    }

    const discount = 0;
    const total = subtotal + deliveryFee - discount;

    const orderId = 'RM-' + Math.floor(1000 + Math.random() * 9000);

    const newOrder = {
      id: orderId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      deliveryAddress: deliveryAddress.trim(),
      area: area || 'inside_dhaka',
      notes: (notes || '').trim(),
      paymentMethod: paymentMethod || 'Cash on Delivery',
      items,
      subtotal,
      deliveryFee,
      discount,
      total,
      status: 'Pending',
      whatsappMessageSent: true,
      createdAt: new Date().toISOString()
    };

    db.orders.unshift(newOrder);

    // Update stock counts
    items.forEach(item => {
      const p = db.products.find(prod => prod.id === item.id);
      if (p && p.stock > 0) {
        p.stock = Math.max(0, p.stock - item.quantity);
      }
    });

    writeDB(db);

    // Generate formatted WhatsApp message & direct URL
    const { rawMessage, waUrl } = buildWhatsAppMessage(newOrder, settings);

    res.status(201).json({
      success: true,
      order: newOrder,
      rawMessage,
      waUrl,
      whatsappNumber: settings.whatsappNumber
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Customer Track Order (by Order ID or Phone number)
app.get('/api/orders/track', (req, res) => {
  try {
    const { query } = req.query;
    if (!query) {
      return res.status(400).json({ success: false, error: 'Please provide an Order ID or Phone number' });
    }

    const cleanQ = query.trim().replace(/^#/, '').toLowerCase();
    const cleanPhoneDigits = query.replace(/\D/g, '');

    const db = readDB();
    const matches = db.orders.filter(o => {
      const matchId = o.id.toLowerCase() === cleanQ || o.id.toLowerCase() === ('rm-' + cleanQ);
      const oPhoneDigits = (o.customerPhone || '').replace(/\D/g, '');
      const matchPhone = cleanPhoneDigits.length >= 8 && oPhoneDigits.includes(cleanPhoneDigits);
      return matchId || matchPhone;
    });

    if (!matches || matches.length === 0) {
      return res.status(404).json({ success: false, error: 'কোনো অর্ডার পাওয়া যায়নি। আপনার অর্ডার আইডি বা সঠিক ফোন নম্বর দিয়ে পুনরায় চেষ্টা করুন।' });
    }

    // Mask phone number partially for privacy
    const sanitized = matches.map(o => {
      const p = o.customerPhone || '';
      const maskedPhone = p.length > 6 ? p.slice(0, 3) + '****' + p.slice(-4) : p;
      return {
        id: o.id,
        customerName: o.customerName,
        customerPhoneMasked: maskedPhone,
        deliveryAddress: o.deliveryAddress,
        area: o.area,
        items: o.items,
        subtotal: o.subtotal,
        deliveryFee: o.deliveryFee,
        total: o.total,
        status: o.status,
        paymentMethod: o.paymentMethod,
        createdAt: o.createdAt
      };
    });

    res.json({ success: true, orders: sanitized, whatsappNumber: db.settings.whatsappNumber });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Get Orders
app.get('/api/orders', (req, res) => {
  try {
    const { pin } = req.query;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    res.json({ success: true, orders: db.orders });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Update Order Status
app.patch('/api/orders/:id/status', (req, res) => {
  try {
    const { pin, status } = req.body;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    const order = db.orders.find(o => o.id === req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found' });
    }

    order.status = status;
    writeDB(db);
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Analytics Overview
app.get('/api/analytics', (req, res) => {
  try {
    const { pin } = req.query;
    const db = readDB();
    if (pin !== db.settings.adminPin) {
      return res.status(403).json({ success: false, error: 'Unauthorized PIN' });
    }

    const totalOrders = db.orders.length;
    const totalRevenue = db.orders
      .filter(o => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + o.total, 0);
    const pendingOrders = db.orders.filter(o => o.status === 'Pending').length;
    const deliveredOrders = db.orders.filter(o => o.status === 'Delivered').length;

    res.json({
      success: true,
      stats: {
        totalOrders,
        totalRevenue,
        pendingOrders,
        deliveredOrders,
        totalProducts: db.products.length
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Client SPA fallback
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`🚀 Rich Mart server running at: http://localhost:${PORT}`);
  console.log(`💬 WhatsApp orders will route to: 8801606609110`);
  console.log(`🔐 Admin PIN default: 1234`);
  console.log(`===============================================`);
});
